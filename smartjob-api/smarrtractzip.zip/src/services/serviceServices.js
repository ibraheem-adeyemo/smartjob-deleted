import db from '../../models';

const {Service} = db;

const createAServiceService = (service) => {
    console.log(service)
    //return Job.create(job)
}

export {
    createAServiceService
}