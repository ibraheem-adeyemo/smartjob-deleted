export interface ResponsesInterface {
    statusCode: null|number|string
    reponseType: null|string
    data: any
    message:string
}