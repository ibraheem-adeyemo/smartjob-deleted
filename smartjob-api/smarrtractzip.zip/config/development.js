export default {
    port: 3306,
    host:'127.0.0.1',
    dbUsername:'root', 
    dbPassword:'Password@11',
    dbSchemaName:'smart_job',
    dialect: 'mysql'
}